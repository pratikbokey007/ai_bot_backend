const { generateChatReply } = require("../services/gemini.service");
const Order = require("../models/order.model"); // तुमचा मंगोडीबी मॉडेल

async function chat(req, res) {
  const { message } = req.body;

  if (!message || typeof message !== "string") {
    return res.status(400).json({
      error: "A valid message is required.",
    });
  }

  try {
    let context = "";

    // १. युजरच्या मेसेजमधून Order ID शोधणे (Regex)
    const orderIdMatch = message.match(/ORD\d+/i);

    if (orderIdMatch) {
      const orderId = orderIdMatch[0].toUpperCase();
      
      // २. MongoDB मधून माहिती काढणे
      const orderData = await Order.findOne({ orderId: orderId });

      if (orderData) {
        context = `[DATABASE INFO]: Order ${orderId} status is ${orderData.status}. Expected delivery: ${orderData.deliveryDate || 'TBD'}.`;
      } else {
        context = `[DATABASE INFO]: Order ${orderId} system madhe सापडली नाही.`;
      }
    }

    // ३. Gemini ला पाठवण्यासाठी प्रॉमप्ट तयार करणे
    const finalPrompt = `
      Role: You are "ShopAssist", an E-commerce Support AI.
      Instructions:
      - Use the provided [DATABASE INFO] to answer.
      - If no database info exists and user asks about order, ask for their Order ID.
      - Be helpful and reply in Marathi-English mix (Hinglish).
      
      ${context}
      
      User Question: ${message}
    `;

    // ४. Gemini Service ला कॉल करणे
    const reply = await generateChatReply(finalPrompt);
    
    return res.json({ reply });

  } catch (error) {
    console.error("Chat controller error:", error.message);
    return res.status(500).json({
      error: "Failed to generate response.",
    });
  }
}

module.exports = {
  chat,
};